/**
 * Bajaj Manager Design System
 * Thème Orange – Blanc
 */

import { Platform } from 'react-native';

export const Colors = {
  light: {
    text: '#1C1917',
    textSecondary: '#78716C',
    textMuted: '#A8A29E',
    background: '#FFF7ED',
    card: '#FFFFFF',
    border: '#FED7AA',
    tint: '#EA580C',
    primary: '#EA580C',
    primaryDark: '#C2410C',
    header: '#C2410C',
    success: '#16A34A',
    warning: '#D97706',
    danger: '#DC2626',
    icon: '#78716C',
    tabIconDefault: '#A8A29E',
    tabIconSelected: '#EA580C',
    inputBg: '#FFFBEB',
    progressBg: '#FED7AA',
  },
  dark: {
    text: '#FAFAF9',
    textSecondary: '#D6D3D1',
    textMuted: '#A8A29E',
    background: '#1C1917',
    card: '#292524',
    border: '#44403C',
    tint: '#FB923C',
    primary: '#FB923C',
    primaryDark: '#C2410C',
    header: '#9A3412',
    success: '#22C55E',
    warning: '#F59E0B',
    danger: '#EF4444',
    icon: '#A8A29E',
    tabIconDefault: '#78716C',
    tabIconSelected: '#FB923C',
    inputBg: '#292524',
    progressBg: '#44403C',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 999,
};

export const Fonts = Platform.select({
  ios: {
    sans: 'system-ui',
    serif: 'ui-serif',
    rounded: 'ui-rounded',
    mono: 'ui-monospace',
  },
  default: {
    sans: 'normal',
    serif: 'serif',
    rounded: 'normal',
    mono: 'monospace',
  },
  web: {
    sans: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    serif: "Georgia, 'Times New Roman', serif",
    rounded: "'SF Pro Rounded', 'Hiragino Maru Gothic ProN', Meiryo, 'MS PGothic', sans-serif",
    mono: "SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  },
});

/** Montant journalier fixe en Ariary */
export const VERSEMENT_JOURNALIER = 30000;
