import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, useFocusEffect } from 'expo-router';
import { Colors, Radius, VERSEMENT_JOURNALIER } from '@/constants/theme';
import { getDashboardStats } from '@/lib/api';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { PrimaryButton } from '@/components/common/PrimaryButton';

export default function AccueilScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [stats, setStats] = useState<Awaited<ReturnType<typeof getDashboardStats>> | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = async () => {
    const s = await getDashboardStats();
    setStats(s);
    setLoading(false);
    setRefreshing(false);
  };

  useFocusEffect(
    useCallback(() => {
      load();
    }, [])
  );

  if (loading || !stats) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color={Colors.light.primary} />
      </View>
    );
  }

  const rate =
    stats.totalAttendu > 0
      ? Math.round((stats.totalRecu / stats.totalAttendu) * 100)
      : 0;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <View style={styles.headerTop}>
          <View style={styles.logoRow}>
            <View style={styles.logoCircle}>
              <Text style={styles.logoEmoji}>🛺</Text>
            </View>
            <View>
              <Text style={styles.greeting}>Bonjour 👋</Text>
              <Text style={styles.teamName}>Bajaj Manager</Text>
            </View>
          </View>
          <TouchableOpacity
            style={styles.bellBtn}
            onPress={() => router.push('/notifications')}
          >
            <IconSymbol name="bell.fill" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={{ paddingBottom: 32 }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              load();
            }}
            tintColor={Colors.light.primary}
          />
        }
      >
        {/* Stats cards */}
        <View style={styles.statsRow}>
          <View style={[styles.statCard, { backgroundColor: '#FFF7ED' }]}>
            <IconSymbol name="car.fill" size={22} color={Colors.light.primary} />
            <Text style={styles.statValue}>{stats.bajajEnService}</Text>
            <Text style={styles.statLabel}>Bajaj en service</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: '#F0FDF4' }]}>
            <IconSymbol name="person.2.fill" size={22} color={Colors.light.success} />
            <Text style={styles.statValue}>{stats.chauffeurCount}</Text>
            <Text style={styles.statLabel}>Chauffeurs</Text>
          </View>
        </View>

        {/* Versements du jour */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Versements du jour</Text>
            <Text style={styles.cardBadge}>{stats.versementsToday} enregistré(s)</Text>
          </View>

          <View style={styles.amountRow}>
            <View>
              <Text style={styles.amountLabel}>Reçu</Text>
              <Text style={styles.amountValue}>
                {stats.totalRecu.toLocaleString('fr-FR')} Ar
              </Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.amountLabel}>Attendu</Text>
              <Text style={[styles.amountValue, { color: Colors.light.textSecondary }]}>
                {stats.totalAttendu.toLocaleString('fr-FR')} Ar
              </Text>
            </View>
          </View>

          {/* Progress */}
          <View style={styles.progressBg}>
            <View
              style={[
                styles.progressFill,
                { width: `${Math.min(rate, 100)}%` },
              ]}
            />
          </View>
          <Text style={styles.progressText}>{rate}% collecté</Text>

          <View style={styles.statusRow}>
            <View style={styles.statusItem}>
              <View style={[styles.dot, { backgroundColor: Colors.light.success }]} />
              <Text style={styles.statusText}>{stats.complets} complets</Text>
            </View>
            <View style={styles.statusItem}>
              <View style={[styles.dot, { backgroundColor: Colors.light.warning }]} />
              <Text style={styles.statusText}>{stats.impayes} restants</Text>
            </View>
          </View>
        </View>

        {/* Actions rapides */}
        <Text style={styles.sectionTitle}>Actions rapides</Text>
        <View style={styles.actions}>
          <PrimaryButton
            title="Nouveau versement"
            icon="plus.circle.fill"
            onPress={() => router.push('/ajouter-versement')}
          />
          <PrimaryButton
            title="Ajouter un Bajaj"
            icon="car.fill"
            variant="outline"
            onPress={() => router.push('/ajouter-bajaj')}
            style={{ marginTop: 10 }}
          />
          <PrimaryButton
            title="Ajouter un chauffeur"
            icon="person.badge.plus"
            variant="outline"
            onPress={() => router.push('/ajouter-chauffeur')}
            style={{ marginTop: 10 }}
          />
        </View>

        {/* Info montant */}
        <View style={styles.infoBox}>
          <IconSymbol name="info.circle" size={18} color={Colors.light.primary} />
          <Text style={styles.infoText}>
            Versement journalier fixe : {VERSEMENT_JOURNALIER.toLocaleString('fr-FR')} Ar
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.light.background },
  center: { alignItems: 'center', justifyContent: 'center' },
  header: {
    backgroundColor: Colors.light.header,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  logoCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoEmoji: { fontSize: 24 },
  greeting: { color: 'rgba(255,255,255,0.85)', fontSize: 13 },
  teamName: { color: '#fff', fontSize: 18, fontWeight: '700' },
  bellBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  scroll: { flex: 1, paddingHorizontal: 16, paddingTop: 16 },
  statsRow: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  statCard: {
    flex: 1,
    borderRadius: Radius.lg,
    padding: 16,
    alignItems: 'center',
    gap: 6,
  },
  statValue: { fontSize: 28, fontWeight: '700', color: Colors.light.text },
  statLabel: { fontSize: 12, color: Colors.light.textSecondary },
  card: {
    backgroundColor: Colors.light.card,
    borderRadius: Radius.lg,
    padding: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  cardTitle: { fontSize: 16, fontWeight: '700', color: Colors.light.text },
  cardBadge: { fontSize: 12, color: Colors.light.textMuted },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  amountLabel: { fontSize: 12, color: Colors.light.textMuted },
  amountValue: { fontSize: 20, fontWeight: '700', color: Colors.light.primary },
  progressBg: {
    height: 8,
    backgroundColor: Colors.light.progressBg,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: Colors.light.primary,
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: Colors.light.textSecondary,
    marginTop: 6,
    textAlign: 'right',
  },
  statusRow: { flexDirection: 'row', gap: 20, marginTop: 12 },
  statusItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { fontSize: 13, color: Colors.light.textSecondary },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.light.text,
    marginBottom: 12,
  },
  actions: { marginBottom: 20 },
  infoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFF7ED',
    borderRadius: Radius.md,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  infoText: { flex: 1, fontSize: 13, color: Colors.light.textSecondary },
});
