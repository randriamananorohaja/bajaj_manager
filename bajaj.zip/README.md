# Bajaj Manager

Application mobile de gestion de flotte Bajaj (Madagascar) — React Native Expo + SQLite offline.

## Fonctionnalités

- **CRUD Bajaj** : marque, matricule, statut, chauffeur assigné
- **CRUD Chauffeurs** : nom, prénom, téléphone, CIN, adresse, **photo**
- **Versements journaliers** : 30 000 Ar, calcul auto du reste, statut complet/partiel/impayé
- **Frais** : visite, vidange, réparation + **photo facture**
- **GPS** : enregistrer la position d’un Bajaj, historique, ouvrir dans Maps
- **Statistiques** : mensuel (versements, frais, bénéfice) + résumé du jour
- **Export Excel** : CSV des versements et frais (ouvrable dans Excel)
- **Historique** unifié versements + frais
- Thème **orange / blanc**

## Installation

```bash
npm install
# ou
npx expo install

npx expo start
```

Pour le GPS sur appareil réel :
```bash
npx expo install expo-location
```

## Connexion (par défaut)

- Téléphone : `0340000000`
- Mot de passe : `bajaj2026`

Modifiables dans `lib/auth.ts`.

## Structure

- `app/` — écrans Expo Router
- `lib/api.ts` — accès SQLite
- `lib/export.ts` — export CSV
- `lib/imagePicker.ts` — photos
- `constants/theme.ts` — couleurs orange

## Build Android

```bash
npx eas build -p android --profile preview
```
